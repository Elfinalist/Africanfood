import UIKit

//class Dog {
//    var name: String
//    var breed: String
//
//    init(name: String, breed: String) {
//        self.name = name
//        self.breed = breed
//    }
//}
//
//let poppy = Dog(name: "Poppy", breed: "Poodle")

struct africanDishes {
    var type: String
    var time: Int
    var feeds: Int

    func timeTaken () {
        print("It takes \(time) minutes for \(type) to cook.")
}
    
    func portions() {
        print("Elvo's portions of \(type) can feed atleast \(feeds) people.")
    }
}

    let meal1 = africanDishes (type:"Ugali", time: 45, feeds: 20)
    let meal2 = africanDishes (type:"Rice", time: 15, feeds: 15)
    let meal3 = africanDishes (type:"Mukimo", time: 20, feeds: 20)
    let meal4 = africanDishes (type:"Fish", time: 30, feeds: 10)


    meal1.timeTaken()
    meal3.portions()
